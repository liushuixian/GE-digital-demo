#include "widget.h"
#include "ui_widget.h"
#include <QtGui>
#include <QAxObject>
#include <QAxWidget>
#include <qaxselect.h>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

        QAxSelect select;
        select.show();
        QAxWidget excel("Excel.Application");
        excel.setProperty("Visible", true);
        QAxObject * workbooks = excel.querySubObject("WorkBooks");
        workbooks->dynamicCall("Open (const QString&)", QString("d:/test.xls"));
        QAxObject * workbook = excel.querySubObject("ActiveWorkBook");
        QAxObject * worksheets = workbook->querySubObject("WorkSheets");
        int intCount = worksheets->property("Count").toInt();
        for (int i = 1; i <= intCount; i++)
        {
            int intVal;
            QAxObject * worksheet = workbook->querySubObject("Worksheets(int)", i);
            qDebug() << i << worksheet->property("Name").toString();

            QAxObject * range1 = worksheet->querySubObject("Cells(1,1)");
            intVal = range1->property("Value").toInt();
            range1->setProperty("Value", QVariant("Number"));
            QAxObject * range2 = worksheet->querySubObject("Cells(1,2)");
            intVal = range2->property("Value").toInt();
            range2->setProperty("Value", QVariant("ID"));
            QAxObject * range3 = worksheet->querySubObject("Cells(1,3)");
            intVal = range3->property("Value").toInt();
            range3->setProperty("Value", QVariant("Name"));
            QAxObject * range4 = worksheet->querySubObject("Cells(1,4)");
            intVal = range4->property("Value").toInt();
            range4->setProperty("Value", QVariant("Quantity"));
            QAxObject * range5 = worksheet->querySubObject("Cells(1,5)");
            intVal = range5->property("Value").toInt();
            range5->setProperty("Value", QVariant("Borrow Time"));
            QAxObject * ranges = worksheet->querySubObject("Cells(1,6)");
            intVal = ranges->property("Value").toInt();
            ranges->setProperty("Value", QVariant("Return Time"));

            QAxObject * rangeq = worksheet->querySubObject("Cells(2,1)");
            intVal = rangeq->property("Value").toInt();
            rangeq->setProperty("Value", QVariant("1"));
            QAxObject * range7 = worksheet->querySubObject("Cells(2,2)");
            intVal = range7->property("Value").toInt();
            range7->setProperty("Value", QVariant("SX1403178"));
            QAxObject * range8 = worksheet->querySubObject("Cells(2,3)");
            intVal = range8->property("Value").toInt();
            range8->setProperty("Value", QVariant("刘相杰"));
            QAxObject * range9 = worksheet->querySubObject("Cells(2,4)");
            intVal = range9->property("Value").toInt();
            range9->setProperty("Value", QVariant("3"));
            QAxObject * range10 = worksheet->querySubObject("Cells(2,5)");
            intVal = range10->property("Value").toInt();
            range10->setProperty("Value", QVariant("20160420 9：30"));
            QAxObject * range11 = worksheet->querySubObject("Cells(2,6)");
            intVal = range11->property("Value").toInt();
            range11->setProperty("Value", QVariant("20160420 15：30"));

            QAxObject * ranga = worksheet->querySubObject("Cells(3,1)");
            intVal = ranga->property("Value").toInt();
            ranga->setProperty("Value", QVariant("2"));
            QAxObject * rangeb = worksheet->querySubObject("Cells(3,2)");
            intVal = rangeb->property("Value").toInt();
            rangeb->setProperty("Value", QVariant("SX1403152"));
            QAxObject * rangec = worksheet->querySubObject("Cells(3,3)");
            intVal = rangec->property("Value").toInt();
            rangec->setProperty("Value", QVariant("李世先"));
            QAxObject * ranged = worksheet->querySubObject("Cells(3,4)");
            intVal = ranged->property("Value").toInt();
            ranged->setProperty("Value", QVariant("2"));
            QAxObject * rangee = worksheet->querySubObject("Cells(3,5)");
            intVal = rangee->property("Value").toInt();
            rangee->setProperty("Value", QVariant("20160420 10：20"));
            QAxObject * rangef = worksheet->querySubObject("Cells(3,6)");
            intVal = rangef->property("Value").toInt();
            rangef->setProperty("Value", QVariant("20160420 17：20"));

            QAxObject * rangg = worksheet->querySubObject("Cells(4,1)");
            intVal = rangg->property("Value").toInt();
            rangg->setProperty("Value", QVariant("3"));
            QAxObject * rangeh = worksheet->querySubObject("Cells(4,2)");
            intVal = rangeh->property("Value").toInt();
            rangeh->setProperty("Value", QVariant("SX1414078"));
            QAxObject * rangei = worksheet->querySubObject("Cells(4,3)");
            intVal = rangei->property("Value").toInt();
            rangei->setProperty("Value", QVariant("陈晨"));
            QAxObject * rangej = worksheet->querySubObject("Cells(4,4)");
            intVal = rangej->property("Value").toInt();
            rangej->setProperty("Value", QVariant("5"));
            QAxObject * rangek = worksheet->querySubObject("Cells(4,5)");
            intVal = rangek->property("Value").toInt();
            rangek->setProperty("Value", QVariant("20160420 8：15"));
            QAxObject * rangel = worksheet->querySubObject("Cells(4,6)");
            intVal = rangel->property("Value").toInt();
            rangel->setProperty("Value", QVariant("20160420 19：15"));

            QAxObject * rangga = worksheet->querySubObject("Cells(5,1)");
            intVal = rangga->property("Value").toInt();
            rangga->setProperty("Value", QVariant("4"));
            QAxObject * rangeha = worksheet->querySubObject("Cells(5,2)");
            intVal = rangeha->property("Value").toInt();
            rangeha->setProperty("Value", QVariant("SX1414065"));
            QAxObject * rangeia = worksheet->querySubObject("Cells(5,3)");
            intVal = rangeia->property("Value").toInt();
            rangeia->setProperty("Value", QVariant("刘梦蕾"));
            QAxObject * rangeja = worksheet->querySubObject("Cells(5,4)");
            intVal = rangeja->property("Value").toInt();
            rangeja->setProperty("Value", QVariant("1"));
            QAxObject * rangeka = worksheet->querySubObject("Cells(5,5)");
            intVal = rangeka->property("Value").toInt();
            rangeka->setProperty("Value", QVariant("20160420 8：34"));
            QAxObject * rangela = worksheet->querySubObject("Cells(5,6)");
            intVal = rangela->property("Value").toInt();
            rangela->setProperty("Value", QVariant("20160420 14：15"));

            QAxObject * ranggb = worksheet->querySubObject("Cells(6,1)");
            intVal = ranggb->property("Value").toInt();
            ranggb->setProperty("Value", QVariant("5"));
            QAxObject * rangehb = worksheet->querySubObject("Cells(6,2)");
            intVal = rangehb->property("Value").toInt();
            rangehb->setProperty("Value", QVariant("SX1414088"));
            QAxObject * rangeib = worksheet->querySubObject("Cells(6,3)");
            intVal = rangeib->property("Value").toInt();
            rangeib->setProperty("Value", QVariant("张天翼"));
            QAxObject * rangejb = worksheet->querySubObject("Cells(6,4)");
            intVal = rangejb->property("Value").toInt();
            rangejb->setProperty("Value", QVariant("10"));
            QAxObject * rangekb = worksheet->querySubObject("Cells(6,5)");
            intVal = rangekb->property("Value").toInt();
            rangekb->setProperty("Value", QVariant("20160420 8：09"));
            QAxObject * rangelb = worksheet->querySubObject("Cells(6,6)");
            intVal = rangelb->property("Value").toInt();
            rangelb->setProperty("Value", QVariant("20160420 16：45"));

            QAxObject * ranggc = worksheet->querySubObject("Cells(7,1)");
            intVal = ranggc->property("Value").toInt();
            ranggc->setProperty("Value", QVariant("6"));
            QAxObject * rangehc = worksheet->querySubObject("Cells(7,2)");
            intVal = rangehc->property("Value").toInt();
            rangehc->setProperty("Value", QVariant("SX1415083"));
            QAxObject * rangeic = worksheet->querySubObject("Cells(7,3)");
            intVal = rangeic->property("Value").toInt();
            rangeic->setProperty("Value", QVariant("沈阳阳"));
            QAxObject * rangejc = worksheet->querySubObject("Cells(7,4)");
            intVal = rangejc->property("Value").toInt();
            rangejc->setProperty("Value", QVariant("2"));
            QAxObject * rangekc = worksheet->querySubObject("Cells(7,5)");
            intVal = rangekc->property("Value").toInt();
            rangekc->setProperty("Value", QVariant("20160420 9：45"));
            QAxObject * rangelc = worksheet->querySubObject("Cells(7,6)");
            intVal = rangelc->property("Value").toInt();
            rangelc->setProperty("Value", QVariant("20160420 14：59"));

            QAxObject * ranggd = worksheet->querySubObject("Cells(8,1)");
            intVal = ranggd->property("Value").toInt();
            ranggd->setProperty("Value", QVariant("7"));
            QAxObject * rangehd = worksheet->querySubObject("Cells(8,2)");
            intVal = rangehd->property("Value").toInt();
            rangehd->setProperty("Value", QVariant("SX1404023"));
            QAxObject * rangeid = worksheet->querySubObject("Cells(8,3)");
            intVal = rangeid->property("Value").toInt();
            rangeid->setProperty("Value", QVariant("张翔"));
            QAxObject * rangejd = worksheet->querySubObject("Cells(8,4)");
            intVal = rangejd->property("Value").toInt();
            rangejd->setProperty("Value", QVariant("3"));
            QAxObject * rangekd = worksheet->querySubObject("Cells(8,5)");
            intVal = rangekd->property("Value").toInt();
            rangekd->setProperty("Value", QVariant("20160420 9：05"));
            QAxObject * rangeld = worksheet->querySubObject("Cells(8,6)");
            intVal = rangeld->property("Value").toInt();
            rangeld->setProperty("Value", QVariant("20160420 21：50"));

            QAxObject * rangge = worksheet->querySubObject("Cells(9,1)");
            intVal = rangge->property("Value").toInt();
            rangge->setProperty("Value", QVariant("8"));
            QAxObject * rangehe = worksheet->querySubObject("Cells(9,2)");
            intVal = rangehe->property("Value").toInt();
            rangehe->setProperty("Value", QVariant("SX1402021"));
            QAxObject * rangeie = worksheet->querySubObject("Cells(9,3)");
            intVal = rangeie->property("Value").toInt();
            rangeie->setProperty("Value", QVariant("杜伟"));
            QAxObject * rangeje = worksheet->querySubObject("Cells(9,4)");
            intVal = rangeje->property("Value").toInt();
            rangeje->setProperty("Value", QVariant("6"));
            QAxObject * rangeke = worksheet->querySubObject("Cells(9,5)");
            intVal = rangeke->property("Value").toInt();
            rangeke->setProperty("Value", QVariant("20160420 9：35"));
            QAxObject * rangele = worksheet->querySubObject("Cells(9,6)");
            intVal = rangele->property("Value").toInt();
            rangele->setProperty("Value", QVariant("20160420 20：30"));

        }
        QAxObject * worksheet = workbook->querySubObject("Worksheets(int)", 1);
        QAxObject * usedrange = worksheet->querySubObject("UsedRange");
        QAxObject * rows = usedrange->querySubObject("Rows");
        QAxObject * columns = usedrange->querySubObject("Columns");
        int intRowStart = usedrange->property("Row").toInt();
        int intColStart = usedrange->property("Column").toInt();
        int intCols = columns->property("Count").toInt();
        int intRows = rows->property("Count").toInt();
        for (int i = intRowStart; i < intRowStart + intRows; i++)
        {
            for (int j = intColStart; j <= intColStart + intCols; j++)
            {
                QAxObject * range = worksheet->querySubObject("Cells(int,int)", i, j );
                qDebug() << i << j << range->property("Value");
            }
        }
        excel.setProperty("DisplayAlerts", 0);
        workbook->dynamicCall("SaveAs (const QString&)", QString("c:/xlsbyqt.xls"));
        excel.setProperty("DisplayAlerts", 1);
       // workbook->dynamicCall("Close (Boolean)", false);
        //excel.dynamicCall("Quit (void)");
}

Widget::~Widget()
{
    delete ui;
}
